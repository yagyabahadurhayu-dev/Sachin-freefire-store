
function buy(id){
alert("You selected Free Fire ID #" + id + ". Contact Sachin to complete the purchase.");
}
